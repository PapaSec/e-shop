<?php

Class Products
{
    function index()
    {
    }
}